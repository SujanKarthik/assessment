s1 = "listen"
s2 = "silent"
print(sorted(s1) == sorted(s2))