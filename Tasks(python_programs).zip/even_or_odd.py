n = 7
if n % 2 == 0:
    print("Even")
else:
    print("Odd")