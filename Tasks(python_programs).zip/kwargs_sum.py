a = {"x":10, "y":20, "z":5}
print(sum(a.values()))