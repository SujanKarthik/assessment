lst = [10, 20, 4, 45, 99]
print(max(lst))
print(min(lst))