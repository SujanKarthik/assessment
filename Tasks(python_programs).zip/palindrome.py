s = "madam"
if s == s[::-1]:
    print(True)
else:
    print(False)