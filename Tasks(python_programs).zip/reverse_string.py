s = "hello"
print(s[::-1])