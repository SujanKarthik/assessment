lst = [10,20,4,45,99]
lst = list(set(lst))
lst.sort()
print(lst[-2])