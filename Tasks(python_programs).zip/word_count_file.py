with open("sample.txt", "r") as f:
    text = f.read()
print(len(text.split()))